"use client";

import React, { useState, useEffect } from "react";

export function WhatsAppFloatingButton() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Always visible on desktop; on mobile, only show after scrolling past the hero banner
      if (window.innerWidth >= 768) {
        setIsVisible(true);
      } else {
        setIsVisible(window.scrollY > 160);
      }
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    window.addEventListener("resize", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("resize", handleScroll);
    };
  }, []);

  const phoneNumber = "2347063668847";
  const defaultMessage = encodeURIComponent(
    "Hello Tullipio Fashion House, I would like to inquire about bespoke tailoring and your latest ready-to-wear pieces."
  );
  const waUrl = `https://wa.me/${phoneNumber}?text=${defaultMessage}`;

  return (
    <aside aria-label="Customer WhatsApp Contact">
      <a
        href={waUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat with Tullipio Fashion House on WhatsApp"
        className={`fixed z-40 group flex items-center justify-center bg-emerald-600 hover:bg-emerald-500 text-white rounded-full shadow-[0_4px_24px_rgba(16,185,129,0.35)] hover:shadow-[0_6px_30px_rgba(16,185,129,0.5)] transition-all duration-300 active:scale-95 focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-2
          bottom-4 right-4 w-12 h-12 p-0
          md:bottom-6 md:right-6 md:w-auto md:h-auto md:p-3.5 md:gap-2
          ${
            isVisible
              ? "opacity-100 translate-y-0 pointer-events-auto"
              : "opacity-0 translate-y-4 pointer-events-none"
          }`}
      >
        {/* WhatsApp Icon */}
        <svg
          className="w-6 h-6 fill-current transition-transform duration-300 md:group-hover:rotate-6 shrink-0"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.746.953 3.71 1.456 5.711 1.457h.004c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.405z" />
        </svg>

        {/* Text expands ONLY on desktop hover — mobile remains perfectly circular */}
        <span className="hidden md:inline-block max-w-0 overflow-hidden whitespace-nowrap md:group-hover:max-w-xs transition-all duration-300 ease-out text-xs font-semibold tracking-wide md:group-hover:pr-1">
          Chat on WhatsApp
        </span>
      </a>
    </aside>
  );
}
